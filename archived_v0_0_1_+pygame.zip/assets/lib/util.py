import math
import sys, os, pygame
from pygame.locals import *

from assets.lib.euclid import *

from settings import *

def load_image(name, colorkey=None, pngTransparency=None):
    fullname = os.path.join('assets/images/', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error, message:
        print 'Cannot load image:', name
        raise SystemExit, message
        
    if colorkey is not None:
        image = image.convert()
        if colorkey is -1:
            colorkey = image.get_at((0,0))
        image.set_colorkey(colorkey, RLEACCEL)
    elif pngTransparency is not None:
        image = image.convert_alpha()
        
    return image, image.get_rect()

def vector_angle(vector):
    """get the angle in degrees of a given vector to the axes"""
    if vector.magnitude_squared() == 0:
        angle = 0
    else:
        angle = int(math.degrees(math.atan2(vector.y, vector.x)))
    return angle


def debug_print(text):
    if DEBUG:
        print text