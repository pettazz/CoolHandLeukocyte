_Justice is a dish best served to a cold._
=============